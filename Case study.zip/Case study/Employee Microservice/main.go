package main

import (
	"encoding/json"
	"fmt"
	"net/http"
)

type employee_details struct {
	Name string `json:"Name"`
	Role string `json:"Role"`
}
type response struct {
	Status string `json:"Status"`
}

func main() {
	http.HandleFunc("/employee", employee)
	http.ListenAndServe(":7000", nil)
}

func employee(w http.ResponseWriter, r *http.Request) {
	name := r.URL.Query().Get("name")
	role := r.URL.Query().Get("role")
	w.Header().Set("Access-Control-Allow-Origin", "*")
	var new_employee employee_details
	new_employee.Name = name
	new_employee.Role = role
	result, err := Db(name, role)
	fmt.Print(result)
	var current response
	if err == nil {
		current.Status = "Employee details added successfully"
	} else {
		current.Status = "Something went wrong"
	}
	json.NewEncoder(w).Encode(current)
}
